const LocationResourcesEN = {
  location_id: 'location id',
  location_name: 'location name',
  description: 'description',
  longitude: 'longitude',
  latitude: 'latitude',
  rating_text: 'Tap to share your experience to help others',
  reviews: 'Reviews',
  review: 'Review:',
  user_name: 'User Name',
  add_photo_btn: 'Add Photo',
  placeholder_text: 'Share your review at this place',
};

export default LocationResourcesEN;

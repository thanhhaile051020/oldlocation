export class SaveLocation {
  saveLocationId: string;
  userId: string;
  locationId: string;
}

export class Tours {
  tourId: string;
  startTime: Date;
  endTime: Date;
  locations: string[];
}

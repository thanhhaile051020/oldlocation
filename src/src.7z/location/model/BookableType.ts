export enum BookableType {
  Room = 'R',
  Projector = 'P'
}

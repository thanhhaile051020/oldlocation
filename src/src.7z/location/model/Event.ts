export class Event {
    eventId?: string;
    eventName?: string;
    startTime?: Date;
    endTime?: Date;
    locationId?: string;
    lat?: number;
    long?: number;
}

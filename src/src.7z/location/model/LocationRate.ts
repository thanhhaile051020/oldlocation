export class LocationRate {
  rateId?: string;
  locationId?: string;
  userId?: string;
  rate?: number;
  rateTime?: Date;
  review?: string;
}

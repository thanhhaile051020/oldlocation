export class Trip {
  tripId: string;
  startTime: Date;
  endTime: Date;
  locations: object[];
}

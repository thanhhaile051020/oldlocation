import * as React from 'react';

export default function About() {
  return (
    <React.Fragment>
      <p>This is About Page</p>
    </React.Fragment>
  );
}

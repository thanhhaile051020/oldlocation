import * as React from 'react';

export default function Photo() {
  return (
    <React.Fragment>
      <p>This is Photo Page</p>
    </React.Fragment>
  );
}
